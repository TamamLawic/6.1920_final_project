int main() {
  int a = 5;
  int b = 6;
  return a + b;
}
