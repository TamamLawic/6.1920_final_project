int main() {
  int a = 6;
  int b = 7;
  return a * b;
}
