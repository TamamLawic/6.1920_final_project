int main() {
  int a = 99;
  int b = 47;
  return a & b;
}
