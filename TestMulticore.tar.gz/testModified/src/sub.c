int main() {
  int a = 13;
  int b = 6;
  return a - b;
}
