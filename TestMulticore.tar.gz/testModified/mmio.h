#ifndef MMIO_H
#define MMIO_H

int getchar();
int putchar(int c);
int exit(int c);

#endif
